#include <stdio.h>

struct Process {
    int pid;
    int burst_time;
    int remaining_time;
    int waiting_time;
    int turnaround_time;
};

int main() {
    int n, time_quantum, total_TAT = 0, total_WT = 0;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];
    
    // Input burst time for each process
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter burst time for Process %d: ", p[i].pid);
        scanf("%d", &p[i].burst_time);
        p[i].remaining_time = p[i].burst_time;
        p[i].waiting_time = 0;
    }
    
    printf("Enter time quantum: ");
    scanf("%d", &time_quantum);

    int time = 0;  // Start from time 0
    int remaining_processes = n;

    // Round Robin Scheduling
    while (remaining_processes > 0) {
        for (int i = 0; i < n; i++) {
            if (p[i].remaining_time > 0) {
                if (p[i].remaining_time <= time_quantum) {
                    time += p[i].remaining_time;
                    p[i].waiting_time = time - p[i].burst_time;
                    p[i].turnaround_time = p[i].waiting_time + p[i].burst_time;
                    p[i].remaining_time = 0;
                    remaining_processes--;
                } else {
                    p[i].remaining_time -= time_quantum;
                    time += time_quantum;
                }
            }
        }
    }

    // Display results
    printf("\nProcess\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        p[i].turnaround_time = p[i].waiting_time + p[i].burst_time;
        printf("P%d\t%d\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].burst_time,
               p[i].waiting_time + p[i].burst_time,  // Completion Time (CT)
               p[i].turnaround_time,
               p[i].waiting_time);
        total_TAT += p[i].turnaround_time;
        total_WT += p[i].waiting_time;
    }

    printf("\nAverage Turnaround Time: %.2f", (float)total_TAT / n);
    printf("\nAverage Waiting Time: %.2f\n", (float)total_WT / n);

    return 0;
}
