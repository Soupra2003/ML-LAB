#include <stdio.h>

struct Process {
    int pid;
    int burst_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
};

int main() {
    int n, total_TAT = 0, total_WT = 0;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];

    // Input burst time for each process
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter burst time for Process %d: ", p[i].pid);
        scanf("%d", &p[i].burst_time);
    }

    // FCFS Scheduling
    int current_time = 0;
    for (int i = 0; i < n; i++) {
        // Completion Time = Arrival Time + Burst Time (Arrival Time is 0 here)
        p[i].completion_time = current_time + p[i].burst_time;
        
        // Turnaround Time = Completion Time - Arrival Time (Arrival Time is 0 here)
        p[i].turnaround_time = p[i].completion_time;
        
        // Waiting Time = Turnaround Time - Burst Time
        p[i].waiting_time = p[i].turnaround_time - p[i].burst_time;
        
        // Update current time for the next process
        current_time = p[i].completion_time;

        // Accumulate total turnaround and waiting times for average calculation
        total_TAT += p[i].turnaround_time;
        total_WT += p[i].waiting_time;
    }

    // Display results
    printf("\nProcess\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].burst_time,
               p[i].completion_time,
               p[i].turnaround_time,
               p[i].waiting_time);
    }

    // Average Turnaround Time and Waiting Time
    printf("\nAverage Turnaround Time: %.2f", (float)total_TAT / n);
    printf("\nAverage Waiting Time: %.2f\n", (float)total_WT / n);

    return 0;
}
