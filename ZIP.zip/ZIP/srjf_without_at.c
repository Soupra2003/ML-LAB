#include <stdio.h>

struct Process {
    int pid;
    int burst_time;
    int remaining_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
};

// Function to sort processes based on remaining burst time
void sortByRemainingTime(struct Process p[], int n) {
    struct Process temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (p[j].remaining_time > p[j + 1].remaining_time) {
                temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }
        }
    }
}

int main() {
    int n, total_TAT = 0, total_WT = 0;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];
    
    // Input burst time for each process
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter burst time for Process %d: ", p[i].pid);
        scanf("%d", &p[i].burst_time);
        p[i].remaining_time = p[i].burst_time;
        p[i].waiting_time = 0;
    }

    int current_time = 0;
    int remaining_processes = n;
    
    // Process execution
    while (remaining_processes > 0) {
        sortByRemainingTime(p, n);  // Sort processes based on remaining burst time

        for (int i = 0; i < n; i++) {
            if (p[i].remaining_time > 0) {
                current_time += p[i].remaining_time;
                p[i].completion_time = current_time;
                p[i].turnaround_time = p[i].completion_time;
                p[i].waiting_time = p[i].turnaround_time - p[i].burst_time;
                p[i].remaining_time = 0;
                remaining_processes--;
            }
        }
    }

    // Display results
    printf("\nProcess\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].burst_time,
               p[i].completion_time,
               p[i].turnaround_time,
               p[i].waiting_time);
        total_TAT += p[i].turnaround_time;
        total_WT += p[i].waiting_time;
    }

    printf("\nAverage Turnaround Time: %.2f", (float)total_TAT / n);
    printf("\nAverage Waiting Time: %.2f\n", (float)total_WT / n);

    return 0;
}
