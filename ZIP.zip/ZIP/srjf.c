#include <stdio.h>

struct Process {
    int pid;
    int arrival_time;
    int burst_time;
    int remaining_time;
    int completion_time;
    int waiting_time;
    int turnaround_time;
};

// Function to sort processes based on arrival time and remaining time
void sortByArrivalAndRemainingTime(struct Process p[], int n, int current_time) {
    struct Process temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (p[j].arrival_time <= current_time && p[j].remaining_time > 0 &&
                (p[j].remaining_time > p[j + 1].remaining_time ||
                (p[j].remaining_time == p[j + 1].remaining_time && p[j].arrival_time > p[j + 1].arrival_time))) {
                temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }
        }
    }
}

int main() {
    int n, total_TAT = 0, total_WT = 0;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];

    // Input arrival time and burst time for each process
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter arrival time and burst time for Process %d: ", p[i].pid);
        scanf("%d %d", &p[i].arrival_time, &p[i].burst_time);
        p[i].remaining_time = p[i].burst_time;
        p[i].waiting_time = 0;
    }

    int current_time = 0;
    int remaining_processes = n;

    // Process execution
    while (remaining_processes > 0) {
        sortByArrivalAndRemainingTime(p, n, current_time);  // Sort based on arrival time and remaining time

        for (int i = 0; i < n; i++) {
            if (p[i].remaining_time > 0 && p[i].arrival_time <= current_time) {
                current_time += p[i].remaining_time;
                p[i].completion_time = current_time;
                p[i].waiting_time = p[i].completion_time - p[i].arrival_time - p[i].burst_time;
                p[i].turnaround_time = p[i].completion_time - p[i].arrival_time;
                p[i].remaining_time = 0;
                remaining_processes--;
            }
        }
    }

    // Display results
    printf("\nProcess\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].arrival_time,
               p[i].burst_time,
               p[i].completion_time,
               p[i].turnaround_time,
               p[i].waiting_time);
        total_TAT += p[i].turnaround_time;
        total_WT += p[i].waiting_time;
    }

    printf("\nAverage Turnaround Time: %.2f", (float)total_TAT / n);
    printf("\nAverage Waiting Time: %.2f\n", (float)total_WT / n);

    return 0;
}
