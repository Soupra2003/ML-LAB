#include <stdio.h>

struct Process {
    int pid;
    int burst_time;
    int priority;
    int completion_time;
    int turnaround_time;
    int waiting_time;
};

// Function to sort processes based on priority
void sortByPriority(struct Process p[], int n) {
    struct Process temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (p[j].priority > p[j + 1].priority) {
                temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }
        }
    }
}

int main() {
    int n;
    float total_TAT = 0, total_WT = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];

    // Input burst time and priority for each process
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter burst time and priority for Process %d: ", p[i].pid);
        scanf("%d %d", &p[i].burst_time, &p[i].priority);
    }

    // Sort processes by priority
    sortByPriority(p, n);

    int current_time = 0;

    for (int i = 0; i < n; i++) {
        p[i].completion_time = current_time + p[i].burst_time;
        p[i].turnaround_time = p[i].completion_time;
        p[i].waiting_time = p[i].turnaround_time - p[i].burst_time;

        total_TAT += p[i].turnaround_time;
        total_WT += p[i].waiting_time;

        current_time = p[i].completion_time;
    }

    // Display results
    printf("\nProcess\tBT\tPriority\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].burst_time,
               p[i].priority,
               p[i].completion_time,
               p[i].turnaround_time,
               p[i].waiting_time);
    }

    printf("\nAverage Turnaround Time: %.2f", total_TAT / n);
    printf("\nAverage Waiting Time: %.2f\n", total_WT / n);

    return 0;
}
