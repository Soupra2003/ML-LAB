echo "Enter First Number : "
read a
echo "Enter Second Number : "
read b

a=$((a+b))
b=$((a-b))
a=$((a-b))

echo "A= $a"
echo "B= $b"
