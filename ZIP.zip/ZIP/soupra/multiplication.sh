echo "Enter a Number :"
read a
echo "Multiplication table for $a"
for((i=1;i<=10;i++))
do
echo "$a x $i = $((a*i))"
done
