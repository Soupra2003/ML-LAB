echo "Enter First Number :"
read a
echo "Enter Second Number :"
read b

c=$a
a=$b
b=$c

echo "A=$a"
echo "B=$b"
