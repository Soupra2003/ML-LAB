echo "Enter Number :"
read n
a=0
sum=0
while [ $a -le $n ]
do
sum=$((sum+a))
a=$((a+1))
done

echo "Sum is :" $sum

