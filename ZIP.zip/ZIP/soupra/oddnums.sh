echo "Enter a Number :"
read n
a=1

while [ $a -le $n ]
do
echo "Value is $a"
a=$((a+2))
done
