echo "Souvik Pramanik"
echo "Adamas University"
