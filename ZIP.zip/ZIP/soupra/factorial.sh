echo "Enter a Number "
read a
fact=1
for((i=2;i<=a;i++)){
fact=$((fact*i))
}
echo "Factorial is :"$fact

