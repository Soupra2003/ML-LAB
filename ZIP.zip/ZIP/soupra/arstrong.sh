echo "Enter a Number"
read c
x=$c
sum=0
r=0
n=0
while [ $x -gt 0 ]
do
r=$((x % 10))
n=$((r * r * r))
sum=$((sum + n))
x=$((x / 10))
done
if [ $sum -eq $c ]
then
echo "Number is Armstrong Number"
else
echo "Number is not Armstrong Number"
fi
