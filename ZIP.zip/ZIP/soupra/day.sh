echo "Enter the day Number :"
read a

case $a in
	1) echo "Sunday";;
	2) echo "Monday";;
	3) echo "Tuesday";;
	4) echo "Wednesday";;
	5) echo "Thursday";;
	6) echo "Friday";;
	7) echo "saturday";;
	*) echo "Invalid Input ! please enter a number between 1 to 7";;
esac
