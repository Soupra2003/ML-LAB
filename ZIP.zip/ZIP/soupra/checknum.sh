echo "Enter a Number : "
read a
if(($a == 0))
then
echo "Number is Zero"
elif(($a > 0))
then
echo "$a is positive"
else
echo "$a is negative"
fi
