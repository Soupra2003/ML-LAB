echo "Enter month number:"
read a

echo "Enter year:"
read b

case $a in
    1|3|5|7|8|10|12)
        echo "Month $a has 31 days"
        ;;
    4|6|9|11)
        echo "Month $a has 30 days"
        ;;
    2)
        if (( (b % 4 == 0 && b % 100 != 0) || (b % 400 == 0) )); then
            echo "February has 29 days"
        else
            echo "February has 28 days"
        fi
        ;;
    *)
        echo "Invalid Month! Please enter a valid month number (1-12)"
        ;;
esac
