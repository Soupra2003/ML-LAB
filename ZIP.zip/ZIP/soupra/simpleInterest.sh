echo "Enter the Amount"
read a
echo "Enter the no of year"
read b
echo "Enter the interest rate"
read c

interest=$((a * b * c/100))

echo "Interest is : $interest"
