get_grade() {
    if [ $1 -ge 90 ]; then
        echo "A+"
    elif [ $1 -ge 80 ]; then
        echo "A"
    elif [ $1 -ge 70 ]; then
        echo "B"
    elif [ $1 -ge 60 ]; then
        echo "C"
    elif [ $1 -ge 50 ]; then
        echo "D"
    else
        echo "F (Fail)"
    fi
}

echo "Enter marks for Subject 1:"
read s1

echo "Enter marks for Subject 2:"
read s2

echo "Enter marks for Subject 3:"
read s3

echo "Grade for Subject 1: $(get_grade $s1)"
echo "Grade for Subject 2: $(get_grade $s2)"
echo "Grade for Subject 3: $(get_grade $s3)"
