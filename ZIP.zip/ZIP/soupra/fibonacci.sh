echo "Enter a Number :"
read n
x=0
y=1

echo "Fibonacci series upto $n"
echo "$x"
echo "$y"

for((i=2;i<n;i++))
do
fn=$((x+y))
echo "$fn"
x=$y
y=$fn
done

