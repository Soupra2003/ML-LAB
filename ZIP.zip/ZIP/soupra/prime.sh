echo "Enter a Number :"
read a

for((i=2;i<$a/2;i++))
do
ans=$((a%i))
if(($ans == 0))
then
echo "$a is not Prime"
exit 0
fi
done
echo "$a is prime"

