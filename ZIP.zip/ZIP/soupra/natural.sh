echo "Enter number:"
read n
a=1

while [ $a -le $n ]
do
    echo "Value is $a"
    a=$((a + 1))
done
