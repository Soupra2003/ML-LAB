echo "Enter First Number :"
read a
echo "Enter Second Number :"
read b

sum=$((a + b))
sub=$((a - b))
mul=$((a * b))
div=$((a / b))

echo "Addition : $sum"
echo "Substraction : $sub"
echo "Multiplication : $mul"
echo "Division : $div"
