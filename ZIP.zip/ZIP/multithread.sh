# Simulated "Thread class"
function thread_class() {
  for i in {1..5}
  do
    echo "Thread using 'Thread class' function: $i"
    sleep 1
  done
}

# Simulated "Runnable interface"
function runnable_interface() {
  for i in {1..5}
  do
    echo "Thread using 'Runnable interface' function: $i"
    sleep 1
  done
}

#!/bin/bash

# Simulate Thread class
thread_class &   # Start in background

# Simulate Runnable interface
runnable_interface &  # Start in background

# Wait for both to finish
wait

echo "Both simulated threads have finished."

