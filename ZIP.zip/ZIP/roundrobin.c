#include <stdio.h>

struct Process {
    int pid;
    int arrival_time;
    int burst_time;
    int remaining_time;
    int completion_time;
    int waiting_time;
    int turnaround_time;
};

int main() {
    int n, time_quantum, total_TAT = 0, total_WT = 0;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    struct Process p[n];
    
    // Input arrival time and burst time for each process
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter arrival time and burst time for Process %d: ", p[i].pid);
        scanf("%d %d", &p[i].arrival_time, &p[i].burst_time);
        p[i].remaining_time = p[i].burst_time;
        p[i].waiting_time = 0;
    }
    
    printf("Enter time quantum: ");
    scanf("%d", &time_quantum);

    int time = 0;  // Start from time 0
    int remaining_processes = n;
    int done = 0;

    // Round Robin Scheduling
    while (remaining_processes > 0) {
        for (int i = 0; i < n; i++) {
            if (p[i].arrival_time <= time && p[i].remaining_time > 0) {
                if (p[i].remaining_time <= time_quantum) {
                    time += p[i].remaining_time;
                    p[i].completion_time = time;
                    p[i].waiting_time = time - p[i].arrival_time - p[i].burst_time;
                    p[i].turnaround_time = p[i].completion_time - p[i].arrival_time;
                    p[i].remaining_time = 0;
                    remaining_processes--;
                } else {
                    p[i].remaining_time -= time_quantum;
                    time += time_quantum;
                }
            }
        }
    }

    // Display results
    printf("\nProcess\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].arrival_time,
               p[i].burst_time,
               p[i].completion_time,
               p[i].turnaround_time,
               p[i].waiting_time);
        total_TAT += p[i].turnaround_time;
        total_WT += p[i].waiting_time;
    }

    printf("\nAverage Turnaround Time: %.2f", (float)total_TAT / n);
    printf("\nAverage Waiting Time: %.2f\n", (float)total_WT / n);

    return 0;
}
